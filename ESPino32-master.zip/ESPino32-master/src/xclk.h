#pragma once

#include "camera_common.h"

esp_err_t camera_enable_out_clock();
